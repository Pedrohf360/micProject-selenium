package json;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Calculadora {

	JSONParser parser = new JSONParser();
	JSONObject leitor = new JSONObject();
	
	try{
		
	}
	
	
}
